<nav class="navbar navbar-default" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">BrandHouse-vConnect-Shippii</a>
        </div>
        <div class="collapse navbar-collapse">
            <?php if(Auth::check()): ?>
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo e(route('home')); ?>">Timeline</a></li>
                    <li><a href="<?php echo e(route('friend.index')); ?>">Friends</a></li>
                    <li><a href="<?php echo e(route('questionnaires/index')); ?>">Questionnaires</a></li>
                    <li><a href="<?php echo e(route('event/index')); ?>">Event</a></li>
                </ul>

            <?php endif; ?>
            <ul class="nav navbar-nav navbar-right">
                <?php if(Auth::check()): ?>
                    <img src="<?php echo e(asset('images/'.Auth::user()->avatar)); ?>" width="50" height="50" class="img-circle"
                         alt="profile picture" title="<?php echo e(Auth::user()->name); ?>">
                    <li>
                        <a href="<?php echo e(route('profile.index', ['username' => Auth::user()->username])); ?>"><?php echo e(Auth::user()->getNameOrUsername()); ?></a>
                    </li>
                    <li><a href="<?php echo e(route('profile.edit')); ?>">Update profile</a></li>
                    <li><a href="<?php echo e(route('auth.signout')); ?>">Sign out</a></li>
                    <form class="navbar-form navbar-left" role="search" action="<?php echo e(route('search.results')); ?>">
                        <div class="form-group">
                            <input type="text" name="query" class="form-control" placeholder="Find people">
                        </div>
                        <button type="submit" class="btn btn-default">Search</button>
                    </form>
                <?php else: ?>
                    <li><a href="<?php echo e(route('auth.signup')); ?>">Sign up</a></li>
                    <li><a href="<?php echo e(route('auth.signin')); ?>">Sign in</a></li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="col-md12">
            <div class="row">
                <div class="col-xs-4">
                    <img src="<?php echo e(asset('images/brandhouse2.png')); ?>" alt="...">
                </div>
                <div class="col-xs-4">
                    <img src="<?php echo e(asset('images/vconnect.png')); ?>" alt="...">
                </div>
                <div class="col-xs-4">
                    <img src="<?php echo e(asset('images/shippii.jpg')); ?>" alt="...">
                </div>
                <br>
                <hr>
                <hr>
            </div>

        </div>
    </div>
</nav>
<?php /**PATH /home/vagrant/code/net/resources/views/templates/partials/navigation.blade.php ENDPATH**/ ?>