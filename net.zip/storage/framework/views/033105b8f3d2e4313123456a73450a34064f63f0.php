

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1 class="text-center">Questionnaires</h1>
                    </div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <hr>
                        <?php if(auth()->user()->isAdmin === 1): ?>
                            <a href="<?php echo e(route('questionnaires/create')); ?>" class="btn btn-primary center-block">New
                                Questionnaire</a>
                        <?php endif; ?>
                        <hr>
                        <div class="col-md-12">
                            <ul class="list-group">
                                <?php $__currentLoopData = $questionnaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionnaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a href="<?php echo e($questionnaire->path()); ?>"><h2><?php echo e($questionnaire->title); ?></h2></a>
                                        <a href="<?php echo e($questionnaire->path()); ?>"><h4><?php echo e($questionnaire->purpose); ?></h4>
                                        </a>
                                        <div class="mt-2">
                                            <small>Share URL</small>
                                            <p>
                                                <a href="<?php echo e($questionnaire->publicPath()); ?>"><?php echo e($questionnaire->publicPath()); ?> </a>
                                            </p>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/net/resources/views/questionnaire/index.blade.php ENDPATH**/ ?>