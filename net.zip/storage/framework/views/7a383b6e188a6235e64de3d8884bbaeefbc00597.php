

<?php $__env->startSection('content'); ?>
<div class="col-md-12 text-center" >
    <a href="<?php echo e(route('auth.signin')); ?>" class="btn btn-primary">Sign in</a>
    <a href="<?php echo e(route('auth.signup')); ?>" class="btn btn-primary">Sign up</a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/net/resources/views/home.blade.php ENDPATH**/ ?>