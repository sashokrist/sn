<?php if(Session::has('info')): ?>
    <div class="alert alert-info" role="alert">
        <?php echo e(Session::get('info')); ?>

    </div>
<?php endif; ?><?php /**PATH /home/vagrant/code/net/resources/views/templates/partials/alerts.blade.php ENDPATH**/ ?>